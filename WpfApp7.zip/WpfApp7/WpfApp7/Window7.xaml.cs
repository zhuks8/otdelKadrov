﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window7.xaml
    /// </summary>
    public partial class Window7 : Window
    {
        public Window7()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                var usern = new Сотрудники();

                usern.ID_сотрудника = Convert.ToInt32(a1.Text);
                usern.Фамилия = a2.Text;
                usern.Имя = a3.Text;
                usern.Отчество = a4.Text;
                usern.Должность = a5.Text;
                usern.Стаж_работы = a6.Text;
                usern.Номер_паспорта = Convert.ToInt32(a7.Text);
                usern.ИНН = a8.Text;
                usern.Состав_семьи = Convert.ToInt32(a9.Text);
                usern.Дата_рождения = a10.DisplayDate;
                usern.Место_проживания = a11.Text;
                usern.Телефон = a12.Text;

                db.Сотрудники.Add(usern);
                db.SaveChanges();

                MessageBox.Show("запись добавлена");
            }
        }
    }
}
