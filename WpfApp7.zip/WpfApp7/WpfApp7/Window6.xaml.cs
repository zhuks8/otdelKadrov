﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window6.xaml
    /// </summary>
    public partial class Window6 : Window
    {
        public Window6()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                var usern = new Начальник();

                usern.Ключ_Нач = Convert.ToInt32(a1.Text);
                usern.ID_Сотрудника = Convert.ToInt32(a2.Text);
                usern.Начальник1 = a3.Text;
                
                db.Начальник.Add(usern);
                db.SaveChanges();

                MessageBox.Show("запись добавлена");
            }
        }
    }
}
