﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window5.xaml
    /// </summary>
    public partial class Window5 : Window
    {
        public Window5()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                var usern = new Командировка();

                usern.Командировка1 = Convert.ToInt32(a1.Text);
                usern.ID_сотрудника = Convert.ToInt32(a2.Text);
                usern.Место_назначения = a3.Text;
                usern.Срок = Convert.ToInt32(a4.Text);
                usern.Цель = a5.Text;
                usern.За_счет_средств = Convert.ToInt32(a6.Text);


                db.Командировка.Add(usern);
                db.SaveChanges();

                MessageBox.Show("запись добавлена");
            }
        }
    }
}
