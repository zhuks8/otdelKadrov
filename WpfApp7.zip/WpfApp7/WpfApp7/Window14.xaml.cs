﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window14.xaml
    /// </summary>
    public partial class Window14 : Window
    {
        public Window14()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                var usern = new Увольнение();

                usern.Ключ_Ув = Convert.ToInt32(a1.Text);
                usern.Дата_составления = a2.DisplayDate;
                usern.Дата_увольнения = a3.DisplayDate;
                usern.ID_сотрудника = Convert.ToInt32(a4.Text);
                usern.Основание = a5.Text;
                usern.К_оплате = Convert.ToInt32(a6.Text);

                db.Увольнение.Add(usern);
                db.SaveChanges();

                MessageBox.Show("запись добавлена");
            }
        }
    }
}
