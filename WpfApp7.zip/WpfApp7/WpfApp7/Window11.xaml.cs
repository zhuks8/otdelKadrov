﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window11.xaml
    /// </summary>
    public partial class Window11 : Window
    {
        public Window11()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                var usern = new Повышение_квалификации();

                usern.Перевод = Convert.ToInt32(a1.Text);
                usern.ID_Сотрудника = Convert.ToInt32(a2.Text);               
                usern.Вид_перевода = a3.Text;
                usern.Прежнее_место_работы = a4.Text;
                usern.Новое_место_работы = a5.Text;
                usern.Основание_работы = a6.Text;

                db.Повышение_квалификации.Add(usern);
                db.SaveChanges();

                MessageBox.Show("запись добавлена");
            }
        }
    }
}
