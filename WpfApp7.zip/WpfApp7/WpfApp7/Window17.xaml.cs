﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window17.xaml
    /// </summary>
    public partial class Window17 : Window
    {
        public Window17()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                var usern = new приём_персонала();

                usern.Фамилия = a1.Text;
                usern.Имя = a2.Text;
                usern.Отчество = a3.Text;
                usern.номер_паспорта = Convert.ToInt32(a4.Text);
                usern.дата_рождения = a5.DisplayDate;
                usern.телефон = a6.Text;
                usern.дата_подачи_заявлений = a7.DisplayDate;

                db.приём_персонала.Add(usern);
                db.SaveChanges();

                MessageBox.Show("запись отправлена");
                Window18 window18 = new Window18();
                window18.Show();
                this.Close();
            }
        }
    }
}
