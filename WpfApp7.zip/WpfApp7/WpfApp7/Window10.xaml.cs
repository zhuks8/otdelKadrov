﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window10.xaml
    /// </summary>
    public partial class Window10 : Window
    {
        public Window10()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                var usern = new Трудовой_договор();

                usern.Ключ_ТД = Convert.ToInt32(a1.Text);
                usern.Ключ_Фирмы = Convert.ToInt32(a2.Text);
                usern.Дата_составления = a3.DisplayDate;
                usern.Дата_принятия = a4.DisplayDate;
                usern.ID_сотрудника = Convert.ToInt32(a5.Text);
                usern.Оклад = Convert.ToInt32(a6.Text);
                usern.Основание = a7.Text;                

                db.Трудовой_договор.Add(usern);
                db.SaveChanges();

                MessageBox.Show("запись добавлена");
            }
        }
    }
}
