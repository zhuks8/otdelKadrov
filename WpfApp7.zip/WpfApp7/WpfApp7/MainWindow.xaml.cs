﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ComboBox_DropDownClosed(object sender, EventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                switch (Combo.SelectedIndex)
                {
                    case 0:
                        var aa = db.Приказ_по_личному_составу.ToList(); DaGrid.ItemsSource = aa;
                        break;
                    case 1:
                        var bb = db.Производственные_приказы.ToList(); DaGrid.ItemsSource = bb;
                        break;
                    case 2:
                        var cc = db.Структурное_подразделение.ToList(); DaGrid.ItemsSource = cc;
                        break;
                    case 3:
                        var gg = db.Больничный.ToList(); DaGrid.ItemsSource = gg;
                        break;
                    case 4:
                        var jj = db.Командировка.ToList(); DaGrid.ItemsSource = jj;
                        break;
                    case 5:
                        var rr = db.Начальник.ToList(); DaGrid.ItemsSource = rr;
                        break;
                    case 6:
                        var r1 = db.Сотрудники.ToList(); DaGrid.ItemsSource = r1;
                        break;
                    case 7:
                        var r2 = db.Отпуск.ToList(); DaGrid.ItemsSource = r2;
                        break;
                    case 8:
                        var r3 = db.Должность.ToList(); DaGrid.ItemsSource = r3;
                        break;
                    case 9:
                        var r4 = db.Трудовой_договор.ToList(); DaGrid.ItemsSource = r4;
                        break;
                    case 10:
                        var r5 = db.Повышение_квалификации.ToList(); DaGrid.ItemsSource = r5;
                        break;
                    case 11:
                        var r6 = db.Табель_рабочего_времени.ToList(); DaGrid.ItemsSource = r6;
                        break;
                    case 12:
                        var r7 = db.Наименование_фирмы.ToList(); DaGrid.ItemsSource = r7;
                        break;
                    case 13:
                        var r8 = db.Увольнение.ToList(); DaGrid.ItemsSource = r8;
                        break;
                    case 14:
                        var r9 = db.logpas.ToList(); DaGrid.ItemsSource = r9;
                        break;
                    case 15:
                        var r10 = db.приём_персонала.ToList(); DaGrid.ItemsSource = r10;
                        break;

                }
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Combo.Text == "Приказ_по_личному_составу")
            {
                Window1 window1 = new Window1();
                window1.Show();
            }
            if (Combo.Text == "Производственные_приказы")
            {
                Window2 window2 = new Window2();
                window2.Show();
            }
            if (Combo.Text == "Структурное_подразделение")
            {
                Window3 window1 = new Window3();
                window1.Show();
            }
            if (Combo.Text == "Больничный")
            {
                Window4 window1 = new Window4();
                window1.Show();
            }
            if (Combo.Text == "Командировка")
            {
                Window5 window1 = new Window5();
                window1.Show();
            }
            if (Combo.Text == "Начальник")
            {
                Window6 window1 = new Window6();
                window1.Show();
            }
            if (Combo.Text == "Сотрудники")
            {
                Window7 window1 = new Window7();
                window1.Show();
            }
            if (Combo.Text == "Отпуск")
            {
                Window8 window1 = new Window8();
                window1.Show();
            }
            if (Combo.Text == "Должность")
            {
                Window9 window1 = new Window9();
                window1.Show();
            }
            if (Combo.Text == "Трудовой_договор")
            {
                Window10 window1 = new Window10();
                window1.Show();
            }
            if (Combo.Text == "Повышение_квалификации")
            {
                Window11 window1 = new Window11();
                window1.Show();
            }
            if (Combo.Text == "Табель_рабочего_времени")
            {
                Window12 window1 = new Window12();
                window1.Show();
            }
            if (Combo.Text == "Наименование_фирмы")
            {
                Window13 window1 = new Window13();
                window1.Show();
            }
            if (Combo.Text == "Увольнение")
            {
                Window14 window1 = new Window14();
                window1.Show();
            }
            if (Combo.Text == "logpas")
            {
                Window16 window1 = new Window16();
                window1.Show();
            }
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {               
                if (Combo.Text == "Приказ_по_личному_составу")
                {
                    var del = (Приказ_по_личному_составу)DaGrid.SelectedItem;
                    var user = db.Приказ_по_личному_составу.FirstOrDefault(dd => dd.номер_приказа == del.номер_приказа);

                    db.Приказ_по_личному_составу.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Производственные_приказы")
                {
                    var del = (Производственные_приказы)DaGrid.SelectedItem;
                    var user = db.Производственные_приказы.FirstOrDefault(dd => dd.номер_приказа == del.номер_приказа);

                    db.Производственные_приказы.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Структурное_подразделение")
                {
                    var del = (Структурное_подразделение)DaGrid.SelectedItem;
                    var user = db.Структурное_подразделение.FirstOrDefault(dd => dd.Ключ_СП == del.Ключ_СП);

                    db.Структурное_подразделение.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Больничный")
                {
                    var del = (Больничный)DaGrid.SelectedItem;
                    var user = db.Больничный.FirstOrDefault(dd => dd.Больничный1 == del.Больничный1);

                    db.Больничный.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Командировка")
                {
                    var del = (Командировка)DaGrid.SelectedItem;
                    var user = db.Командировка.FirstOrDefault(dd => dd.Командировка1 == del.Командировка1);

                    db.Командировка.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Начальник")
                {
                    var del = (Начальник)DaGrid.SelectedItem;
                    var user = db.Начальник.FirstOrDefault(dd => dd.Ключ_Нач == del.Ключ_Нач);

                    db.Начальник.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Сотрудники")
                {
                    var del = (Сотрудники)DaGrid.SelectedItem;
                    var user = db.Сотрудники.FirstOrDefault(dd => dd.ID_сотрудника == del.ID_сотрудника);

                    db.Сотрудники.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Отпуск")
                {
                    var del = (Отпуск)DaGrid.SelectedItem;
                    var user = db.Отпуск.FirstOrDefault(dd => dd.Отпуск1 == del.Отпуск1);

                    db.Отпуск.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Должность")
                {
                    var del = (Должность)DaGrid.SelectedItem;
                    var user = db.Должность.FirstOrDefault(dd => dd.ID_должности == del.ID_должности);

                    db.Должность.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Трудовой_договор")
                {
                    var del = (Трудовой_договор)DaGrid.SelectedItem;
                    var user = db.Трудовой_договор.FirstOrDefault(dd => dd.Ключ_ТД == del.Ключ_ТД);

                    db.Трудовой_договор.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }

                if (Combo.Text == "Повышение_квалификации")
                {
                        var del = (Повышение_квалификации)DaGrid.SelectedItem;
                        var user = db.Повышение_квалификации.FirstOrDefault(dd => dd.Перевод == del.Перевод);

                        db.Повышение_квалификации.Remove(user);

                        db.SaveChanges();
                        MessageBox.Show("Запись удалена");
                }
                                                                           
                if (Combo.Text == "Табель_рабочего_времени")
                {
                        var del = (Табель_рабочего_времени)DaGrid.SelectedItem;
                        var user = db.Табель_рабочего_времени.FirstOrDefault(dd => dd.ID_сотрудника == del.ID_сотрудника);

                        db.Табель_рабочего_времени.Remove(user);

                        db.SaveChanges();
                        MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Наименование_фирмы")
                {
                    var del = (Наименование_фирмы)DaGrid.SelectedItem;
                    var user = db.Наименование_фирмы.FirstOrDefault(dd => dd.ключ_фирмы == del.ключ_фирмы);

                    db.Наименование_фирмы.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "Увольнение")
                {
                    var del = (Увольнение)DaGrid.SelectedItem;
                    var user = db.Увольнение.FirstOrDefault(dd => dd.Ключ_Ув == del.Ключ_Ув);

                    db.Увольнение.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
                if (Combo.Text == "logpas")
                {
                    var del = (logpas)DaGrid.SelectedItem;
                    var user = db.logpas.FirstOrDefault(dd => dd.login == del.login);

                    db.logpas.Remove(user);

                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Excel.Application excel = new Excel.Application();
            excel.Visible = true; //www.yazilimkodlama.com
            Workbook workbook = excel.Workbooks.Add(System.Reflection.Missing.Value);
            Worksheet sheet1 = (Worksheet)workbook.Sheets[1];

            for (int j = 0; j < DaGrid.Columns.Count; j++) //Başlıklar için
            {
                Range myRange = (Range)sheet1.Cells[1, j + 1];
                sheet1.Cells[1, j + 1].Font.Bold = true; //Başlığın Kalın olması için
                sheet1.Columns[j + 1].ColumnWidth = 15; //Sütun genişliği ayarı
                myRange.Value2 = DaGrid.Columns[j].Header;
            }
            for (int i = 0; i < DaGrid.Columns.Count; i++)
            { //www.yazilimkodlama.com
                for (int j = 0; j < DaGrid.Items.Count; j++)
                {
                    TextBlock b = DaGrid.Columns[i].GetCellContent(DaGrid.Items[j]) as TextBlock;
                    Microsoft.Office.Interop.Excel.Range myRange = (Microsoft.Office.Interop.Excel.Range)sheet1.Cells[j + 2, i + 1];
                    myRange.Value2 = b.Text;
                }
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Window18 window18 = new Window18();
            window18.Show();
            this.Close();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog()==true)
            {
                printDialog.PrintVisual(DaGrid, "Печать");
            }
        }
    }
}
