﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window8.xaml
    /// </summary>
    public partial class Window8 : Window
    {
        public Window8()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                var usern = new Отпуск();

                usern.Отпуск1 = Convert.ToInt32(a1.Text);
                usern.Дата_составления = a2.DisplayDate;
                usern.ID_сотрудника = Convert.ToInt32(a3.Text);
                usern.Период_работы = a4.DisplayDate;
                usern.Основной_отпуск = a5.DisplayDate;
                usern.Дополнительный_отпуск = a6.DisplayDate;               
                usern.Количество_дней = Convert.ToInt32(a7.Text);                
                usern.Период_к_оплате = Convert.ToInt32(a8.Text);
                
                db.Отпуск.Add(usern);
                db.SaveChanges();

                MessageBox.Show("запись добавлена");
            }
        }
    }
}
