﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window12.xaml
    /// </summary>
    public partial class Window12 : Window
    {
        public Window12()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                var usern = new Табель_рабочего_времени();

                usern.ID_сотрудника = Convert.ToInt32(a1.Text);
                usern.За_перевод = a2.Text;
                usern.Фамилия = a3.Text;
                usern.Имя = a4.Text;
                usern.Отчество = a5.Text;
                usern.Кол_во_отработанных_дней = Convert.ToInt32(a6.Text);
                usern.Кол_во_выходных = Convert.ToInt32(a7.Text);
                usern.Отпуск = Convert.ToInt32(a8.Text);
                usern.Командировка = Convert.ToInt32(a9.Text);
                usern.Больничный = Convert.ToInt32(a10.Text);

                db.Табель_рабочего_времени.Add(usern);
                db.SaveChanges();

                MessageBox.Show("запись добавлена");
            }
        }
    }
}
