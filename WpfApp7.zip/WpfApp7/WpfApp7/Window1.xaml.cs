﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ОтделКадровEntities())
            {
                var usern = new Приказ_по_личному_составу();

                usern.номер_приказа = Convert.ToInt32(a1.Text);
                usern.дата = a2.DisplayDate;
                usern.Больничный = a3.Text;
                usern.Отпуск = a4.Text;
                usern.Трудовой_договор = a5.Text;
                usern.Увольнение = a6.Text;

                db.Приказ_по_личному_составу.Add(usern);
                db.SaveChanges();

                MessageBox.Show("запись добавлена");
            }
        }

        private void a1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
